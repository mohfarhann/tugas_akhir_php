<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\tbl_biodata;

class biodataControllers extends Controller
{
    public function getData(){
        $data = DB::table('tbl_biodata')->get();
        if(count($data) > 0){
            $res['message'] = "Success!";
            $res['value'] = $data;
            return response($res);
        }else{
            $res['message'] = "Empty!";
            $res['value'] = $data;
            return response($res);
        }
    }

    public function store(Request $req){
        $this->validate($req, [
            'file' => 'required|max: 2048'
        ]);

        $file = $req->file('file');
        $fileName = $file->getClientOriginalName();
        $upploadAddress = 'data_file';
        if($file->move($upploadAddress, $fileName)){
            $data = tbl_biodata::create([
                'nama' => $req->nama,
                'no_telp' => $req->no_telp,
                'alamat' => $req->alamat,
                'hobi' => $req->hobi,
                'foto' => $fileName
            ]);
            $res['message'] = "Success!";
            $res['value'] = $data;
            return response($res);
        }
    }

    public function update(Request $req){
        if(!empty($req->file)){
            $this->validate($req, [
                'file' => 'required|max: 2048'
            ]);
            $file = $req->file('file');
            $fileName = $file->getClientOriginalName();
            $upploadAddress = 'data_file';
            $file->move($upploadAddress, $fileName);
            $data = DB::table('tbl_biodata')->where('id', $req->id)->get();
            foreach($data as $datas){
                @unlink(public_path('data_file/'.$datas->foto));
                $x = DB::table('tbl_biodata')->where('id', $req->id)->update([
                    'nama' => $req->nama,
                    'no_telp' => $req->no_telp,
                    'alamat' => $req->alamat,
                    'hobi' => $req->hobi,
                    'foto' => $fileName
                ]);
                $res['message'] = "Success!";
                $res['value'] = $x;
                return response($res);
            }
        }else{
            $data = DB::table('tbl_biodata')->where('id', $req->id)->get();
            foreach($data as $datas){
                $y = DB::table('tbl_biodata')->where('id', $req->id)->update([
                    'nama' => $req->nama,
                    'no_telp' => $req->no_telp,
                    'alamat' => $req->alamat,
                    'hobi' => $req->hobi
                ]);
                $res['message'] = "Success!";
                $res['value'] = $y;
                return response($res);
            }
        }
    }

    public function erase($id){
        $data = DB::table('tbl_biodata')->where('id', $id)->get();
        foreach($data as $datas){
            if(file_exists(public_path('data_file/'.$datas->foto))){
                @unlink(public_path('data_file/'.$datas->foto));
                DB::table('tbl_biodata')->where('id', $id)->delete();
                $res['message'] = "Success!";
                return response($res);
            }else{
                $res['message'] = "empty!";
                return response($res);
            }
        }
    }
}
 